import AddDoctor from './adddoctor';
import AddDept from './department';
import PatientLog from './patientlog';
import Appointments from './appointments';
import Slot from './slot';
import { DashboardHospital } from './dashboard';
import HospitalLogin from './hospitallogin';

export {AddDoctor,AddDept,PatientLog,Appointments,Slot,DashboardHospital,HospitalLogin};