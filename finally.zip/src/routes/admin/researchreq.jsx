import React from 'react'

function Researchreq() {
  return (
   <>
   <div className="outer">
    <div className="top-row">
        <h1>Admin Research Requests</h1>
        <div className="back-button">
                <button>Back to home</button>
        </div>
    </div>
   </div>
   </>
  )
}

export default Researchreq