import Admin from "./login";
import DashboardAdmin from "./dashboard";
import Verify from "./verify";
import VerifyDetails from "./verify2";
import Blacklist from "./blacklist";
import Addhospital from "./aaddhosp1";
import Addhospitals from "./addhospitals";

export {Admin,DashboardAdmin,Verify,VerifyDetails,Blacklist,Addhospital,Addhospitals}