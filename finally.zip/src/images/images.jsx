import Logo from "./logo.png";
import BG from "./bg.png";
import Profile from "./Profile.png"

export { Logo, BG ,Profile};
