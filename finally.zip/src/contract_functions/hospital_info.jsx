
// Function to set hospital data
export function setHospitalData(
    _username,
    _encryptedPrivateKey
)  {
    
}

// Function to get hospital data
export function getHospitalData(_username){

}

// Function to update hospital data
export function updateHospitalData(
    _username,
    _hospitalName,
    _place,
    _license,
    _ownership,
    _contact,
    _contractAddress
)  {

}