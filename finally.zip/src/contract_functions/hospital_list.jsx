// Function to set hospital information
export function setHospital(_place,_name,_username_contractAddress) {
  
}

// Function to check if a place already exists
export function placeExists(place) {

}

// Function to get the list of places
export function getPlaces() {
    
}

// Function to get hospital names and usernames from a place
export function getHospitalsByPlace(_place) {
   
}