// Function to check if a username exists
export function usernameExists(_username) {

}

// Function to add a username-region pair
export function addUsernameRegion(_username, _region)  {

}

// Function to get the region associated with a username
export function getRegion(_username) {

}