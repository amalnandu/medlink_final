
// Function to set user data
export function setUserData(
    _username,
    _encryptedPrivateKey,
    _encryptedCPABESecretKey,
    _attributes
)  {
    
}




// Function to get user data
export function getUserData(_username){

}

// Function to update user status
export function updateUserStatus(_username, _status)  {
    
}


// Function to clear private, cp-abe keys
export function clearKeys(_username)  {
    
}
// Function to insert CP-ABE secret key
export function insertCPABEKey(_username,_encryptedCPABESecretKey )  {
    
}
// Function to add an attribute to the attribute array and clear CP-ABE secret key
export function addAttribute(_username, _attribute)  {
    
}

// Function to remove an attribute from the attribute array and clear CP-ABE secret key
export function removeAttribute(_username,_attribute)  {
    
}

// Function to return the list of attributes
export function getAttributes( _username)  {
  
}

// Function to set hospital, hospital name, and department
export function setHospitalInfo(
    _username,
    _hospitalName,
    _department,
    _hospitalContract
    
)  {

}

// Function to update name field
export function updateName(_username,  _name)  {
    
}
    


//function to delete user data
export function deleteUser(_username)  {

}

// Function to insert CID into tempFiles array
export function insertCID(_username, _cid)  {

}

// Function to remove old CID from tempFiles array
export function removeCID(_username, _oldCID)  {
 
}