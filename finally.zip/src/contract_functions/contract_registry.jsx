


// Function to insert key-value pair
export function insertContractAddress(_key,_contractAddress)  {

}




// Function to get contract address by key
export function getContractAddress(_key) {

}

// Function to get addresses of multiple contracts
export function getContractsAndAddresses(_keys){

}
export function overwriteEntry(_key,_contractAddress) {
  
}
