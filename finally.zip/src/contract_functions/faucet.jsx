export function topUp(_amount) {
    // No need to do anything else, as the ETH is already in the contract
}

export function pay(_recipient,_amount) {
   
}

export function checkBalance() {
  
}