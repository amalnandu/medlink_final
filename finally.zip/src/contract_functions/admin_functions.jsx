export function addHospital(
    _name,
    _place,
    _license,
    _ownership,
    _contact,
    _username,
    _encryptedPrivateKey,
    _address
)  {
   
}