 // Function to add an appointment
 export function addAppointment(
    _username,
    _date,
    _token,
    _hospitalUsername,
    _hospitalName,
    _department,
    _doctorUsername,
    _doctorName
    )  {

}


export function bytes32ToString( _bytes32)  {

}

export function cancelAppointment(
_username,
_date,
_hospitalUsername,
_token
)  {

}

export function completeAppointment(
 _username,
 _date,
 _time,
 _hospitalUsername,
 _token,
 _cid,
 _description
)  {

}



export function getEMRDetails(_username,_date)  {

}

export function setEMRResearchStatus(_username, _cid,  _researchStatus)  {

}

export function removeSharingEntry(
_username,
 _cid,
 _hospitalUsername,
 _doctorUsername
)  {

}


export function getSharingDetails( _username,  _cid)  {

}